def jumlah(a,b):
    c = a+b
    return c

hasil = jumlah(4,5)

# membuat anonymous function dengan lambda

kali = lambda x,y: x*y
hasil = kali(3,4)
print(hasil)
# set, himpunan:

superhero = set()

superhero.add("wiro sableng")
superhero.add("gundala")
superhero.add("saras 008")
superhero.add(212)

print(superhero)

ganjil = {1,3,5,7,9}
genap = {2,4,6,8,10}
prima = {2,3,5,7}

print(ganjil.union(genap))
print(ganjil.intersection(prima))

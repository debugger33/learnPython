def tambah(a,b):
    print(a,'+',b,'=',a+b)

def kurang(a,b):
    print(a,'-',b,'=',a-b)

def main():
    print('ini adalah fungsi utama dari matematika')

if __name__ == '__main__':
    main()
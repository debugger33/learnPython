import matematika as mm

mm.tambah(3,5)
mm.kurang(3,5)

def kecepatan(jarak, waktu):
    print('menghitung kecepatan')
    return jarak / waktu


def waktu_tempuh(kecepatan, jarak):
    print('menghitung waktu tempuh')
    return jarak / kecepatan
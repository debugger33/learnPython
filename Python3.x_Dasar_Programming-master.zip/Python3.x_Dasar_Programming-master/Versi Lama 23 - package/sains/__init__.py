from .matematika import *
from .fisika import *
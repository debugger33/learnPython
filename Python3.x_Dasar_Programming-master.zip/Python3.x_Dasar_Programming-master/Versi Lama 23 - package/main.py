from sains import tambah

tambah(2,1)
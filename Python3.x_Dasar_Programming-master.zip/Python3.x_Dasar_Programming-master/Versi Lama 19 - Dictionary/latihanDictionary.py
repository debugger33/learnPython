# dictionary

member1 = {"ID":101,
           "Nama":"Faqihza Mukhlish",
           "Pekerjaan":"Mahasiswa",
           "Status member":"Gold"
           }

member2 = {"ID":102,
           "Nama":"Ujang Pintu",
           "Pekerjaan":"reparasi pintu",
           "Status member":"Berlian"}

memberlist = {101:member1,102:member2}

print(memberlist[101])
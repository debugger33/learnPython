
data = "apa kabs?"

def cek_modul():
    print("hallo gan")

print("ini adalah modul saya")
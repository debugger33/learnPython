# List
Ganjil = [1,3,5,7,9]

# Tuple
Genap = (2,4,6,6,8,10)

print(type(Ganjil))
print(type(Genap))

print(Genap)